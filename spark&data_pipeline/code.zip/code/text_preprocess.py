from autocorrect import Speller
import re
import gensim.parsing.preprocessing as gsp
from gensim import utils



spell = Speller(lang = "en", fast=True)

filters = [
           gsp.strip_tags,
           gsp.strip_punctuation,
           gsp.strip_multiple_whitespaces,
           gsp.strip_numeric,
           gsp.remove_stopwords,
           gsp.strip_short,
          ]

def clean_text_gsp(s):
    s = utils.to_unicode(s)
    for f in filters:
        s = f(s)
    return s

def clean_text(s):
    s = s.lower()
    s = s.replace('amp', '')
    emoji_pattern = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002702-\U000027B0"
        u"\U000024C2-\U0001F251"
        "]+", flags=re.UNICODE)
    s = emoji_pattern.sub(r'', s) # no emoji
    s = re.sub(r"( )+$|(\n|\\n)|((https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b)|(#\S*)|(@[A-Za-z0-9_]+)", " ", s, flags=re.MULTILINE+re.DOTALL)
    return s

def preprocess(s):
    # remove emojis
    s = clean_text(s)
    # correct spell
    s = spell(s)
    # remove stopwords
    s = clean_text_gsp(s)
    return s


