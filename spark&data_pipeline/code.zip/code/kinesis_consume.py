import boto3
from pyspark.sql.types import *
from pyspark.sql.functions import *



auth = {"aws_access_key_id": "AKIAYNX4CGYHGXURYRF5",
        "aws_secret_access_key":"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"}


kinesisDF = spark.rea


