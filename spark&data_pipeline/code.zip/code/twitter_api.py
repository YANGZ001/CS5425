import configparser
import tweepy
import boto3
import json
import uuid

import text_preprocess

config = configparser.ConfigParser()
config.read('config.ini')
api_key = config['twitter']['api_key']
api_key_secret = config['twitter']['api_key_secret']
access_token = config['twitter']['access_token']
access_token_secret = config['twitter']['access_token_secret']

kinesis_stream_name = config['aws']['stream_name']
aws_access_key = config['aws']['access_key']
aws_access_key_secret = config['aws']['access_key_secret']
region_name = config['aws']['region']

partition_key = str(uuid.uuid4())
kinesis_client = boto3.client('kinesis',
                              region_name=region_name,  # enter the region
                              aws_access_key_id=aws_access_key,  # fill your AWS access key id
                              aws_secret_access_key=aws_access_key_secret)  # fill you aws secret access key


class MyStreamListener(tweepy.Stream):
    def on_status(self, status):
        try:
            text = status.extended_tweet["full_text"]
        except AttributeError:
            text = status.text
        data = {
            'tweet_text': text_preprocess.preprocess(text),
            'created_at': str(status.created_at),
            'user_id': status.user.id,
            'user_name': status.user.name,
            'user_location': status.user.location,
        }
        print(data['tweet_text'])
        response = kinesis_client.put_record(
            StreamName=kinesis_stream_name,
            Data=json.dumps(data),
            PartitionKey=partition_key)

        print('Status: ' +
              json.dumps(response['ResponseMetadata']['HTTPStatusCode']))

    def on_error(self, status):
        print(status)


def main():
    # authentication
    auth = tweepy.OAuthHandler(api_key, api_key_secret)
    auth.set_access_token(access_token, access_token_secret)
    api = tweepy.API(auth)
    stream_tweet = MyStreamListener(api_key, api_key_secret, access_token, access_token_secret)
    stream_tweet.filter(languages=["en"], track=['#UkraineRussiaWar', '#Ukraine', '#Russia',
                                                 '#standwithrussia', '#standwithukraine'])


if __name__ == "__main__":
    main()
